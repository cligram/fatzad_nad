~~This is Simple README 

~~ Source Superflux For Supergroups 

+~~Developer By : @Mustafaflux On Telegram ,

To install on C9 your next steps



#Step1 : writ this > in Terminal 

sudo apt-get update 



#step2 : writ this > in Terminal 

sudo apt-get install libreadline-dev libconfig-dev libssl-dev lua5.2 liblua5.2-dev libevent-dev make unzip git redis-server g++ 
libjansson-dev libpython-dev expat libexpat1-dev



#step3 : writ >

git clone https://github.com/mustafaflux/superflux-bot.git


#step4 : Writ >

cd superflux-bot



step5 : Writ >

./launch.sh install 



(When the installation finishes)



step6 : Writ >

./launch.sh 



Then ask You Number To put him Bot

[[ If You Want install on VPS DO JUST From #step3 to #step6]]

----------------------------

For the inauguration #SourceSuperflux 



️#one_Commnd_in_New_terimnal 💠



sudo apt-get update && sudo apt-get upgrade -y && sudo apt-get autoremove && sudo apt-get autoclean && sudo apt-get install 
libreadline-dev libconfig-dev libssl-dev lua5.2 liblua5.2-dev libevent-dev make unzip git redis-server g++ libjansson-dev 
libpython-dev expat libexpat1-dev -y && cd $HOME && rm -rf superflux-bot && rm -rf .telegram-cli && git clone https://github.com/mustafaflux/superflux-bot.git && cd superflux-bot && ./launch.sh install && ./launch.sh
~~~~~
